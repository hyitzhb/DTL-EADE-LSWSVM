function [model,H] = lssvmMATLAB(model) 
% Only for intern LS-SVMlab use;
%
% MATLAB implementation of the LS-SVM algorithm. This is slower
% than the C-mex implementation, but it is more reliable and flexible;
%
%
% This implementation is quite straightforward, based on MATLAB's
% backslash matrix division (or PCG if available) and total kernel
% matrix construction. It has some extensions towards advanced
% techniques, especially applicable on small datasets (weighed
% LS-SVM, gamma-per-datapoint)

% Copyright (c) 2011,  KULeuven-ESAT-SCD, License & help @ http://www.esat.kuleuven.be/sista/lssvmlab


%fprintf('~');
%
% is it weighted LS-SVM ?
%
weighted = (length(model.gam)>model.y_dim);
if and(weighted,length(model.gam)~=model.nb_data),
  warning('not enough gamma''s for Weighted LS-SVMs, simple LS-SVM applied');
  weighted=0;
end

% computation omega and H
omega = kernel_matrix(model.xtrain(model.selector, 1:model.x_dim), ...
    model.kernel_type, model.kernel_pars);


% initiate alpha and b
model.b = zeros(1,model.y_dim);
model.alpha = zeros(model.nb_data,model.y_dim);

for i=1:model.y_dim %执行所有的10个分类器
    H = omega;%把核矩阵赋值给H
    model.selector=~isnan(model.ytrain(:,i));%记录每个样本在第i个分类器中结果为NaN的赋予0，否则赋予1
    nb_data=sum(model.selector);
    if size(model.gam,2)==model.nb_data, 
      try invgam = model.gam(i,:).^-1; catch, invgam = model.gam(1,:).^-1;end
      for t=1:model.nb_data, H(t,t) = H(t,t)+invgam(t); end
    else
      try invgam = model.gam(i,1).^-1; catch, invgam = model.gam(1,1).^-1;end
      for t=1:model.nb_data, H(t,t) = H(t,t)+invgam; end
    end 
    S_1=H(model.selector,model.selector);%支持向量之间的乘积
    S_2=model.ytrain(model.selector,i);%支持向量对应的标签
    S_3=ones(nb_data,1);
    

    v = H(model.selector,model.selector)\model.ytrain(model.selector,i);
    %eval('v  = pcg(H,model.ytrain(model.selector,i), 100*eps,model.nb_data);','v = H\model.ytrain(model.selector, i);');
    nu = H(model.selector,model.selector)\ones(nb_data,1);
    %nu 是松弛变量和拉格朗日乘子 a 的一个比例系数，--惩罚因子？
    %eval('nu = pcg(H,ones(model.nb_data,i), 100*eps,model.nb_data);','nu = H\ones(model.nb_data,i);');
    s = ones(1,nb_data)*nu(:,1);
    model.b(i) = (nu(:,1)'*model.ytrain(model.selector,i))./s;
    %具体地说，这个公式中，model.selector 是支持向量的索引集合，
    %model.ytrain 是训练数据的标签，nu 是在模型求解过程中得到的一组参数，
    %s 是 LSSVM 模型中的一组参数，即模型中惩罚因子的倒数。
    %上述公式的含义是：对于每一个训练标签的类别 i，计算该类别对应的偏置项 b(i) 的值。
    %计算方法是将 nu 的第一列向量与训练数据的标签进行矩阵乘积，再除以 s。
    %这个计算过程实际上就是对偏置项的推导公式：
    %b = y_s - sum(alpha_i * y_i * K(x_i, x_s))
    %进行了一定的简化。
    %其中 y_s 是支持向量 x_s 对应的训练标签，
    %alpha_i 是样本 xi 对应的拉格朗日乘子，K(x_i, x_s) 是核函数的值，表示样本 xi 和 x_s 之间的相似度。
    %整体来说，这个公式是用来计算 LSSVM 模型中的偏置项的，它需要利用训练数据和模型参数进行计算。
    %其中，支持向量和拉格朗日乘子是模型求解的结果，而 s 值通常是手动设定的一个常数。
    model.alpha(model.selector,i) = v(:,1)-(nu(:,1)*model.b(i));
    %在 LSSVM 工具箱中，lssvmMATLAB 函数中的 model.alpha(model.selector,i) = v(:,1)-(nu(:,1)*model.b(i)) 
    %是用来更新 LSSVM 模型中的拉格朗日乘子 alpha 的值的。
    %具体地说，这个公式中，v 是在优化过程中计算出的一组向量，它是 SMO 算法的中间变量之一。
    %nu 是在模型求解过程中得到的一组参数，model.b(i) 是模型中第 i 类样本对应的偏置项。
    %整个公式的含义是：对于模型中的第 i 类样本，通过 nu 和 model.b(i) 计算出该类别对应的偏置项，
    %然后用一个由 v 和前面计算的偏置项组成的向量来更新该类别样本的拉格朗日乘子 alpha 的值。
    %这个更新是通过减去 nu 的第一列向量乘以偏置项来实现的。
    %拉格朗日乘子是优化问题中的一组参数，它们的值决定了模型的性能和效果，
    %因此在 LSSVM 模型求解中，需要通过迭代的方式不断更新拉格朗日乘子的值。
    %这个公式就是用来更新拉格朗日乘子的一个步骤，它需要利用一些中间变量和模型参数进行计算
end
return




